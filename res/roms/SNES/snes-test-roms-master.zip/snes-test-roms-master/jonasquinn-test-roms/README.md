# Jonas Quinn's collection of test ROMs

Posted by Jonas Quinn [on the BBoard][p].

[p]: https://helmet.kafuka.org/bboard/thread.php?pid=2461#2461

> That zip includes test ROMs by various authors, not just byuu's.

In particular,
[snestest_082506](./snestest_082506/)
is a collection of test ROMs
posted on 2006-08-25 to a forgotten location.
