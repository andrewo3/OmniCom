# KungFuFurby's Test ROM collection

Posted by user KungFuFurby in the Mesen-S thread [on the nesdev forum][p].

> > If anyone has `test_nmi` / `test_irq` to give Sour, I'm sure those test ROMs
> > test the behavior those two games rely on.
>
> Like this collection of tests I found one day, trying to go hunting for some
> other elusive test ROMs that byuu was looking for? They're from 2005-2008,
> though, and some of them are $200-byte headered... most of them are HDMA/IRQ
> tests. Two of them are `test_nmi` and `test_irq`. I found these in 2016 while
> I was attempting to go hunting myself.

[p]: https://forums.nesdev.com/viewtopic.php?p=237153#p237153
