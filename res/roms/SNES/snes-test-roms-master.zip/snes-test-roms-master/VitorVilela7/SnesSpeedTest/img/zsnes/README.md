### Version 1.51 (speed test v3.2)
![ZSNES](zsnes151_v32.png?raw=true "ZSNES")
### Version 1.51
![ZSNES](zsnes151.png?raw=true "ZSNES")
### Version 1.50
![ZSNES](zsnes150.png?raw=true "ZSNES")
### Version 1.42
![ZSNES](zsnes142.png?raw=true "ZSNES")
### Version 1.41
![ZSNES](zsnes141.png?raw=true "ZSNES")
### Version 1.36
![ZSNES](zsnes136.png?raw=true "ZSNES")
### Version 1.30
![ZSNES](zsnes130.png?raw=true "ZSNES")
### Version 1.25
![ZSNES](zsnes125.png?raw=true "ZSNES")
### Version 1.20
![ZSNES](zsnes120.png?raw=true "ZSNES")
