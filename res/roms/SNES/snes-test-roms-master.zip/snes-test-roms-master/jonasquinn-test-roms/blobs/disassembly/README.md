Test ROM disassemblies
======================

The sources for the test ROMs in the parent directory have been lost,
but Jonas Quinn manually disassembled them
to make it more clear how they work.

The disassemblies depend on standard utility headers Near used,
`header_lorom.asm`,
`libx816.asm`,
`libclock.asm`, and
`libmenu.asm`.
These headers can be found in
[the snestest directory](../../snestest_082506/).
