# SNES Tests by gilyon

This is a `git subtree` mirror of [the original repository][r].
Run `./update-sources` to update the mirror to the latest version.

[r]: https://github.com/gilyon/snes-tests.git

