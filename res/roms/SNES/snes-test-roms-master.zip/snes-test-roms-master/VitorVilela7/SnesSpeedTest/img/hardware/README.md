### 1L8B-10 (v5.1)
SA-1 marking: RF5A123 6LD 8Z

Thanks QcRetro for the picture and testing on hardware.
Video is also available [here](v51-1L8B-10/video.mkv).

![1L8B-10 Page 1](v51-1L8B-10/v51-1.JPG?raw=true "1L8B-10 Page 1")
![1L8B-10 Page 2](v51-1L8B-10/v51-2.JPG?raw=true "1L8B-10 Page 2")
![1L8B-10 Page 3](v51-1L8B-10/v51-3.JPG?raw=true "1L8B-10 Page 3")
![1L8B-10 Page 4](v51-1L8B-10/v51-4.JPG?raw=true "1L8B-10 Page 4")

### 1L8B-10 (v3.1)
SA-1 marking: RF5A123 6LD 8Z

Thanks QcRetro for the picture and testing on hardware.

![1L8B-10](1L8B-10.jpg?raw=true "1L8B-10")

### 1L3B-20 (v3.1)
SA-1 marking: RF5A123 6FF 7B

Thanks ikari_01 for the picture and testing on hardware.

![1L3B-20](1L3B-20.jpg?raw=true "1L3B-20")

##### 1-CHIP version:
![1L3B-201-CHIP](1L3B-20-1CHIP.jpg?raw=true "1L3B-20 (1-CHIP)")
