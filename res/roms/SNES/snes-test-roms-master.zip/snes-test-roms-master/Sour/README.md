# SNES Tests by Sour

This is a `git subtree` mirror of [the original repository][r].
Run `./update-sources` to update the mirror to the latest version.

[r]: https://github.com/SourMesen/SnesTests

The [expected results][m] were recorded
from revision 71c50e3 of the original repository.

[m]: ./dma_irq_test + op_timing_test_v2 GPM-02 NTSC 2019_07_10-8IDqGtNKgLk.mp4
