#include "glob_const.h"

const int BUFFER_LEN = 1024;
std::string config_dir;
char sep = '/';
int web;