  - Incorporate all the other test ROMs from tukuyomi's
    `misc/roms/` directory
  - Remove duplicates
  - Try to figure out what each test is testing,
    and how to tell if it's passed or failed
