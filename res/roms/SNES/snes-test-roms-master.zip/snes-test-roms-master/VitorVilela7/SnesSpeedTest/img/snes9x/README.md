### Version 1.39
![Snes9x 1.39](snes9x_1.39.png?raw=true "Snes9x 1.39")
### Versions 1.40, 1.41 and 1.41.1
![Snes9x 1.40-1.41.1](snes9x_1.40.png?raw=true "Snes9x 1.40-1.41.1")
### Versions 1.42 and 1.43
![Snes9x 1.42/1.43](snes9x_1.42.png?raw=true "Snes9x 1.42/1.43")
### Version 1.50
![Snes9x 1.50](snes9x_1.50.png?raw=true "Snes9x 1.50")
### Version 1.51
![Snes9x 1.51](snes9x_1.51.png?raw=true "Snes9x 1.51")
### Version 1.52
![Snes9x 1.52](snes9x_1.52.png?raw=true "Snes9x 1.52")
### Versions 1.53, 1.54, 1.54.1 and 1.55
![Snes9x 1.53-1.55](snes9x_1.53.png?raw=true "Snes9x 1.53-1.55")
### Versions 1.56, 1.56.1 and 1.56.2
![Snes9x 1.56-1.56.2](snes9x_1.56.png?raw=true "Snes9x 1.56-1.56.2")

